package com.openai.platformrunner;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private GameView gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        gameView = new GameView();
        setContentView(gameView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (gameView != null) gameView.resumeGame();
    }

    @Override
    protected void onPause() {
        if (gameView != null) gameView.pauseGame();
        super.onPause();
    }

    private final class GameView extends SurfaceView implements SurfaceHolder.Callback, Runnable {
        private static final float WORLD_H = 720f;
        private static final float PLAYER_W = 52f;
        private static final float PLAYER_H = 82f;
        private static final float GRAVITY_HELD = 1550f;
        private static final float GRAVITY_FALL = 2350f;
        private static final float WALK_SPEED = 225f;
        private static final float RUN_SPEED = 355f;
        private static final float GROUND_ACCEL = 1950f;
        private static final float AIR_ACCEL = 1050f;
        private static final float FRICTION = 2350f;
        private static final float SKID_DECEL = 3300f;
        private static final float COYOTE_TIME = 0.105f;
        private static final float JUMP_BUFFER = 0.135f;
        private static final float CHAIN_WINDOW = 0.52f;

        private final SurfaceHolder holder;
        private Thread gameThread;
        private volatile boolean running;
        private long previousNs;
        private float accumulator;

        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final List<Block> blocks = new ArrayList<>();

        private float px = 150f;
        private float py = 470f;
        private float vx = 0f;
        private float vy = 0f;
        private boolean grounded = false;
        private boolean wasGrounded = false;
        private int wallDir = 0;
        private float cameraX = 0f;
        private float runPhase = 0f;
        private float airborneTime = 0f;
        private float coyote = 0f;
        private float jumpBuffer = 0f;
        private float chainTimer = 0f;
        private int jumpChain = 0;
        private float skidTimer = 0f;
        private float spinAngle = 0f;
        private float spinVelocity = 0f;
        private float squash = 0f;
        private float groundPoundLock = 0f;

        private boolean left;
        private boolean right;
        private boolean down;
        private boolean runButton;
        private boolean jumpHeld;
        private boolean jumpTap;
        private boolean jumpReleased;
        private boolean keyLeft;
        private boolean keyRight;
        private boolean keyDown;
        private boolean keyRun;
        private boolean keyJump;
        private boolean keyJumpTap;
        private boolean keyJumpRelease;

        private float screenW = 1920f;
        private float screenH = 1080f;
        private float scale = 1f;
        private float logicalW = 1280f;

        private final RectF leftZone = new RectF();
        private final RectF rightZone = new RectF();
        private final RectF downZone = new RectF();
        private final RectF runZone = new RectF();
        private final RectF jumpZone = new RectF();

        GameView() {
            super(MainActivity.this);
            holder = getHolder();
            holder.addCallback(this);
            setFocusable(true);
            setFocusableInTouchMode(true);
            buildLevel();
            textPaint.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD));
        }

        private void buildLevel() {
            blocks.clear();
            // Ground strips with readable gaps; these are plain terrain, not franchise objects.
            addBlock(-300, 610, 960, 180);
            addBlock(760, 610, 720, 180);
            addBlock(1580, 610, 980, 180);
            addBlock(2690, 610, 760, 180);
            addBlock(3540, 610, 1500, 180);

            // Simple training terrain for jumps and wall kicks.
            addBlock(540, 505, 130, 28);
            addBlock(930, 470, 180, 28);
            addBlock(1230, 405, 180, 28);
            addBlock(1760, 515, 150, 28);
            addBlock(2040, 445, 190, 28);
            addBlock(2330, 370, 140, 28);
            addBlock(2870, 500, 180, 28);
            addBlock(3190, 420, 170, 28);
            addBlock(3720, 500, 150, 28);
            addBlock(4010, 430, 170, 28);

            // Vertical walls arranged as a wall-kick lane.
            addBlock(2510, 325, 44, 285);
            addBlock(2635, 245, 44, 365);
            addBlock(3370, 350, 44, 260);
        }

        private void addBlock(float x, float y, float w, float h) {
            blocks.add(new Block(x, y, w, h));
        }

        @Override
        public void surfaceCreated(SurfaceHolder surfaceHolder) {
            resumeGame();
        }

        @Override
        public void surfaceChanged(SurfaceHolder surfaceHolder, int format, int width, int height) {
            screenW = width;
            screenH = height;
            recalcViewport();
        }

        @Override
        public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
            pauseGame();
        }

        void resumeGame() {
            if (running || !holder.getSurface().isValid()) return;
            running = true;
            previousNs = System.nanoTime();
            gameThread = new Thread(this, "PlatformRunnerLoop");
            gameThread.start();
        }

        void pauseGame() {
            running = false;
            Thread t = gameThread;
            gameThread = null;
            if (t != null && t != Thread.currentThread()) {
                try { t.join(400); } catch (InterruptedException ignored) { }
            }
        }

        @Override
        public void run() {
            final float fixed = 1f / 120f;
            while (running) {
                long now = System.nanoTime();
                float elapsed = Math.min(0.05f, (now - previousNs) / 1_000_000_000f);
                previousNs = now;
                accumulator += elapsed;
                while (accumulator >= fixed) {
                    update(fixed);
                    accumulator -= fixed;
                }
                drawFrame();
                try { Thread.sleep(2); } catch (InterruptedException ignored) { }
            }
        }

        private void recalcViewport() {
            scale = screenH / WORLD_H;
            logicalW = screenW / scale;
            float y0 = WORLD_H - 155f;
            leftZone.set(32, y0, 142, WORLD_H - 35);
            rightZone.set(150, y0, 260, WORLD_H - 35);
            downZone.set(92, WORLD_H - 280, 202, WORLD_H - 170);
            runZone.set(logicalW - 315, WORLD_H - 170, logicalW - 185, WORLD_H - 40);
            jumpZone.set(logicalW - 165, WORLD_H - 215, logicalW - 25, WORLD_H - 55);
        }

        private float approach(float value, float target, float amount) {
            if (value < target) return Math.min(value + amount, target);
            if (value > target) return Math.max(value - amount, target);
            return value;
        }

        private boolean hit(float x, float y, float w, float h, Block b) {
            return x < b.x + b.w && x + w > b.x && y < b.y + b.h && y + h > b.y;
        }

        private void update(float dt) {
            boolean inLeft = left || keyLeft;
            boolean inRight = right || keyRight;
            boolean inDown = down || keyDown;
            boolean inRun = runButton || keyRun;
            boolean inJumpHeld = jumpHeld || keyJump;

            if (jumpTap || keyJumpTap) jumpBuffer = JUMP_BUFFER;
            jumpTap = false;
            keyJumpTap = false;
            if (jumpReleased || keyJumpRelease) {
                if (vy < -120f) vy *= 0.55f;
                jumpReleased = false;
                keyJumpRelease = false;
            }

            jumpBuffer = Math.max(0f, jumpBuffer - dt);
            chainTimer = Math.max(0f, chainTimer - dt);
            coyote = grounded ? COYOTE_TIME : Math.max(0f, coyote - dt);
            groundPoundLock = Math.max(0f, groundPoundLock - dt);

            int axis = (inRight ? 1 : 0) - (inLeft ? 1 : 0);
            float maxSpeed = inRun ? RUN_SPEED : WALK_SPEED;
            boolean crouching = grounded && inDown && Math.abs(vx) < 150f;

            if (grounded && axis == 0) {
                vx = approach(vx, 0f, FRICTION * dt);
                skidTimer = Math.max(0f, skidTimer - dt * 2f);
            } else if (axis != 0 && !crouching) {
                boolean reversing = Math.abs(vx) > 165f && Math.signum(vx) != axis;
                float a = grounded ? (reversing ? SKID_DECEL : GROUND_ACCEL) : AIR_ACCEL;
                vx = approach(vx, axis * maxSpeed, a * dt);
                if (grounded && reversing) skidTimer = Math.min(0.3f, skidTimer + dt);
                else skidTimer = Math.max(0f, skidTimer - dt * 1.5f);
            }

            // Resolve horizontal movement first so a wall contact can feed a same-frame wall kick.
            wallDir = 0;
            px += vx * dt;
            for (Block b : blocks) {
                if (!hit(px, py, PLAYER_W, PLAYER_H, b)) continue;
                if (vx > 0f) {
                    px = b.x - PLAYER_W;
                    wallDir = 1;
                } else if (vx < 0f) {
                    px = b.x + b.w;
                    wallDir = -1;
                }
                vx = 0f;
            }

            if (jumpBuffer > 0f) {
                if (grounded || coyote > 0f) {
                    boolean reverseFlip = skidTimer > 0.045f && axis != 0;
                    if (crouching) {
                        vy = -735f;
                        vx = axis == 0 ? (vx >= 0 ? -185f : 185f) : axis * 245f;
                        spinVelocity = axis >= 0 ? 510f : -510f;
                        jumpChain = 0;
                    } else if (reverseFlip) {
                        vy = -700f;
                        vx = axis * 285f;
                        spinVelocity = -axis * 560f;
                        jumpChain = 0;
                        skidTimer = 0f;
                    } else {
                        if (chainTimer > 0f && Math.abs(vx) > 185f && jumpChain > 0) {
                            jumpChain = Math.min(3, jumpChain + 1);
                        } else {
                            jumpChain = 1;
                        }
                        float jumpSpeed = jumpChain == 1 ? 610f : (jumpChain == 2 ? 655f : 720f);
                        vy = -jumpSpeed;
                        spinVelocity = jumpChain == 3 ? (vx >= 0 ? 500f : -500f) : 0f;
                    }
                    grounded = false;
                    coyote = 0f;
                    chainTimer = 0f;
                    jumpBuffer = 0f;
                    airborneTime = 0f;
                    squash = -0.12f;
                } else if (wallDir != 0) {
                    vx = -wallDir * 350f;
                    vy = -625f;
                    jumpChain = 0;
                    jumpBuffer = 0f;
                    spinVelocity = -wallDir * 420f;
                    airborneTime = 0f;
                    groundPoundLock = 0.13f;
                }
            }

            if (!grounded && inDown && groundPoundLock <= 0f && airborneTime > 0.11f && vy > -130f) {
                vy = Math.max(vy, 930f);
                vx = approach(vx, 0f, 1900f * dt);
                spinVelocity = 0f;
            }

            if (!grounded && wallDir != 0 && axis == wallDir && vy > 145f) {
                vy = Math.min(vy, 240f);
            }

            float gravity = (inJumpHeld && vy < 0f) ? GRAVITY_HELD : GRAVITY_FALL;
            vy += gravity * dt;
            vy = Math.min(vy, 1120f);

            wasGrounded = grounded;
            grounded = false;
            py += vy * dt;
            for (Block b : blocks) {
                if (!hit(px, py, PLAYER_W, PLAYER_H, b)) continue;
                if (vy >= 0f) {
                    py = b.y - PLAYER_H;
                    vy = 0f;
                    grounded = true;
                } else {
                    py = b.y + b.h;
                    vy = 0f;
                }
            }

            if (grounded) {
                if (!wasGrounded) {
                    if (airborneTime > 0.12f && Math.abs(vx) > 160f && jumpChain > 0) {
                        chainTimer = CHAIN_WINDOW;
                    } else if (jumpChain > 0) {
                        chainTimer = 0.22f;
                    }
                    squash = 0.18f;
                    spinAngle = 0f;
                    spinVelocity = 0f;
                }
                airborneTime = 0f;
                if (chainTimer <= 0f && Math.abs(vx) < 120f) jumpChain = 0;
            } else {
                airborneTime += dt;
            }

            squash = approach(squash, 0f, dt * 2.8f);
            spinAngle += spinVelocity * dt;
            if (grounded) spinAngle = approach(spinAngle, 0f, 900f * dt);
            runPhase += Math.abs(vx) * dt * 0.055f;

            // Respawn after a missed jump.
            if (py > WORLD_H + 170f) {
                px = Math.max(120f, cameraX + 180f);
                py = 360f;
                vx = 0f;
                vy = 0f;
                jumpChain = 0;
            }
            px = Math.max(-100f, Math.min(px, 4800f));

            float targetCam = Math.max(0f, px - logicalW * 0.38f);
            cameraX += (targetCam - cameraX) * Math.min(1f, dt * 5.2f);
        }

        private void drawFrame() {
            if (!holder.getSurface().isValid()) return;
            Canvas c = null;
            try {
                c = holder.lockCanvas();
                if (c == null) return;
                screenW = c.getWidth();
                screenH = c.getHeight();
                recalcViewport();
                c.save();
                c.scale(scale, scale);
                drawBackground(c);
                drawTerrain(c);
                drawPlayer(c);
                drawControls(c);
                drawHud(c);
                c.restore();
            } finally {
                if (c != null) holder.unlockCanvasAndPost(c);
            }
        }

        private void drawBackground(Canvas c) {
            p.setShader(new LinearGradient(0, 0, 0, WORLD_H, Color.rgb(75, 143, 188), Color.rgb(205, 222, 196), Shader.TileMode.CLAMP));
            c.drawRect(0, 0, logicalW, WORLD_H, p);
            p.setShader(null);

            float parallax = cameraX * 0.17f;
            // distant sun
            p.setColor(Color.argb(150, 255, 232, 172));
            c.drawCircle(logicalW * 0.78f, 145f, 54f, p);

            // soft clouds, intentionally original simple silhouettes
            for (int i = -1; i < 9; i++) {
                float x = i * 330f - (parallax % 330f);
                float y = 120f + (i % 3) * 58f;
                p.setColor(Color.argb(92, 255, 255, 255));
                c.drawOval(new RectF(x, y, x + 170, y + 52), p);
                c.drawOval(new RectF(x + 55, y - 18, x + 215, y + 50), p);
            }

            // layered far hills
            drawHillBand(c, 430f, 110f, cameraX * 0.11f, Color.rgb(82, 129, 129));
            drawHillBand(c, 505f, 85f, cameraX * 0.20f, Color.rgb(73, 112, 104));

            // sparse reeds/trees in the mid-distance
            p.setColor(Color.rgb(54, 91, 82));
            for (int i = -2; i < 30; i++) {
                float x = i * 190f - ((cameraX * 0.30f) % 190f);
                float h = 30f + ((i * 23) & 31);
                c.drawRect(x, 530f - h, x + 7f, 535f, p);
                c.drawOval(new RectF(x - 14, 500f - h, x + 22, 530f - h), p);
            }
        }

        private void drawHillBand(Canvas c, float base, float height, float scroll, int color) {
            p.setColor(color);
            path.reset();
            path.moveTo(-120, WORLD_H);
            path.lineTo(-120, base);
            float start = -240f - (scroll % 280f);
            for (float x = start; x < logicalW + 400f; x += 280f) {
                path.quadTo(x + 70, base - height, x + 140, base - height * 0.55f);
                path.quadTo(x + 215, base - height * 1.05f, x + 280, base);
            }
            path.lineTo(logicalW + 200, WORLD_H);
            path.close();
            c.drawPath(path, p);
        }

        private void drawTerrain(Canvas c) {
            c.save();
            c.translate(-cameraX, 0);
            for (Block b : blocks) {
                if (b.x + b.w < cameraX - 80 || b.x > cameraX + logicalW + 80) continue;
                p.setColor(Color.rgb(39, 66, 70));
                c.drawRoundRect(new RectF(b.x, b.y, b.x + b.w, b.y + b.h), 7, 7, p);
                p.setColor(Color.rgb(69, 112, 98));
                c.drawRect(b.x + 4, b.y + 5, b.x + b.w - 4, b.y + Math.min(22f, b.h - 4), p);
                p.setColor(Color.rgb(133, 169, 117));
                c.drawRect(b.x + 4, b.y + 3, b.x + b.w - 4, b.y + 8, p);
                if (b.h > 45) {
                    p.setColor(Color.argb(55, 230, 242, 217));
                    for (float yy = b.y + 42; yy < b.y + b.h; yy += 38) {
                        for (float xx = b.x + 22; xx < b.x + b.w; xx += 54) {
                            c.drawCircle(xx + ((int)(yy / 38) % 2) * 12, yy, 2.8f, p);
                        }
                    }
                }
            }
            c.restore();
        }

        private void drawPlayer(Canvas c) {
            float sx = px - cameraX + PLAYER_W / 2f;
            float sy = py + PLAYER_H / 2f;
            float speed01 = Math.min(1f, Math.abs(vx) / RUN_SPEED);
            float lean = grounded ? Math.max(-0.13f, Math.min(0.13f, vx / RUN_SPEED * 0.12f)) : 0f;
            float stretchX = 1f - squash * 0.45f;
            float stretchY = 1f + squash;

            c.save();
            c.translate(sx, sy);
            c.rotate(spinAngle);
            c.scale(stretchX, stretchY);
            c.shear(lean, 0f);

            float leg = grounded ? (float)Math.sin(runPhase) * 12f * speed01 : 5f;
            float arm = grounded ? (float)Math.sin(runPhase + Math.PI) * 11f * speed01 : -6f;

            // shadow is drawn in player-local style only while near ground
            // legs
            p.setStrokeWidth(10f);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(Color.rgb(27, 38, 48));
            c.drawLine(-11, 19, -13 - leg * 0.55f, 38, p);
            c.drawLine(11, 19, 13 + leg * 0.55f, 38, p);
            p.setStrokeWidth(8f);
            p.setColor(Color.rgb(232, 177, 78));
            c.drawLine(-15 - leg * 0.55f, 39, -25 - leg, 41, p);
            c.drawLine(15 + leg * 0.55f, 39, 25 + leg, 41, p);

            // arms
            p.setStrokeWidth(9f);
            p.setColor(Color.rgb(31, 47, 57));
            c.drawLine(-18, -6, -28 - arm * 0.45f, 12 + arm * 0.35f, p);
            c.drawLine(18, -6, 28 + arm * 0.45f, 12 - arm * 0.35f, p);

            // jacket / torso
            p.setColor(Color.rgb(36, 63, 72));
            c.drawRoundRect(new RectF(-22, -21, 22, 25), 12, 12, p);
            p.setColor(Color.rgb(79, 182, 160));
            c.drawRoundRect(new RectF(-18, -18, 18, 20), 10, 10, p);
            p.setColor(Color.rgb(238, 136, 67));
            c.drawRect(-18, -14, 18, -8, p);

            // head and hair/hood silhouette
            p.setColor(Color.rgb(30, 45, 54));
            c.drawCircle(0, -34, 23f, p);
            p.setColor(Color.rgb(237, 218, 181));
            c.drawOval(new RectF(-16, -49, 17, -20), p);
            p.setColor(Color.rgb(35, 56, 65));
            path.reset();
            path.moveTo(-20, -39);
            path.lineTo(-13, -55);
            path.lineTo(5, -59);
            path.lineTo(20, -46);
            path.lineTo(17, -38);
            path.lineTo(4, -48);
            path.lineTo(-10, -44);
            path.close();
            c.drawPath(path, p);
            p.setColor(Color.rgb(28, 41, 47));
            c.drawCircle(8, -34, 2.4f, p);

            // orange scarf tail emphasizes direction and speed
            p.setColor(Color.rgb(238, 136, 67));
            path.reset();
            path.moveTo(-15, -13);
            float scarfDir = vx >= 0 ? -1f : 1f;
            path.lineTo(-15 + scarfDir * (20 + 17 * speed01), -8);
            path.lineTo(-12 + scarfDir * (18 + 13 * speed01), 1);
            path.close();
            c.drawPath(path, p);
            c.restore();
        }

        private void drawControls(Canvas c) {
            drawButton(c, leftZone, "←", left || keyLeft, 44f);
            drawButton(c, rightZone, "→", right || keyRight, 44f);
            drawButton(c, downZone, "↓", down || keyDown, 38f);
            drawButton(c, runZone, "RUN", runButton || keyRun, 26f);
            drawButton(c, jumpZone, "JUMP", jumpHeld || keyJump, 26f);
        }

        private void drawButton(Canvas c, RectF r, String label, boolean active, float textSize) {
            p.setColor(active ? Color.argb(150, 238, 136, 67) : Color.argb(92, 14, 29, 37));
            c.drawRoundRect(r, 28, 28, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3f);
            p.setColor(Color.argb(140, 242, 246, 235));
            c.drawRoundRect(r, 28, 28, p);
            p.setStyle(Paint.Style.FILL);
            textPaint.setTextSize(textSize);
            textPaint.setColor(Color.argb(220, 248, 249, 240));
            textPaint.setTextAlign(Paint.Align.CENTER);
            Paint.FontMetrics fm = textPaint.getFontMetrics();
            float cy = r.centerY() - (fm.ascent + fm.descent) / 2f;
            c.drawText(label, r.centerX(), cy, textPaint);
        }

        private void drawHud(Canvas c) {
            textPaint.setTextAlign(Paint.Align.LEFT);
            textPaint.setTextSize(20f);
            textPaint.setColor(Color.argb(210, 247, 249, 239));
            String state;
            if (!grounded && wallDir != 0) state = "WALL";
            else if (jumpChain == 3 && !grounded) state = "TRIPLE";
            else if (Math.abs(vx) > WALK_SPEED + 30) state = "RUN";
            else state = "MOVE";
            c.drawText(state + "   JUMP " + Math.max(1, jumpChain), 22f, 34f, textPaint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            boolean newLeft = false, newRight = false, newDown = false, newRun = false, newJump = false;
            int action = e.getActionMasked();
            int actionIndex = e.getActionIndex();
            for (int i = 0; i < e.getPointerCount(); i++) {
                if ((action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP) && i == actionIndex) continue;
                float lx = e.getX(i) / scale;
                float ly = e.getY(i) / scale;
                if (leftZone.contains(lx, ly)) newLeft = true;
                if (rightZone.contains(lx, ly)) newRight = true;
                if (downZone.contains(lx, ly)) newDown = true;
                if (runZone.contains(lx, ly)) newRun = true;
                if (jumpZone.contains(lx, ly)) newJump = true;
            }
            if (action == MotionEvent.ACTION_CANCEL) {
                newLeft = newRight = newDown = newRun = newJump = false;
            }
            if (newJump && !jumpHeld) jumpTap = true;
            if (!newJump && jumpHeld) jumpReleased = true;
            left = newLeft;
            right = newRight;
            down = newDown;
            runButton = newRun;
            jumpHeld = newJump;
            return true;
        }

        @Override
        public boolean onKeyDown(int keyCode, KeyEvent event) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_DPAD_LEFT:
                case KeyEvent.KEYCODE_A: keyLeft = true; return true;
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                case KeyEvent.KEYCODE_D: keyRight = true; return true;
                case KeyEvent.KEYCODE_DPAD_DOWN:
                case KeyEvent.KEYCODE_S: keyDown = true; return true;
                case KeyEvent.KEYCODE_SHIFT_LEFT:
                case KeyEvent.KEYCODE_SHIFT_RIGHT: keyRun = true; return true;
                case KeyEvent.KEYCODE_SPACE:
                case KeyEvent.KEYCODE_BUTTON_A:
                    if (!keyJump) keyJumpTap = true;
                    keyJump = true;
                    return true;
            }
            return super.onKeyDown(keyCode, event);
        }

        @Override
        public boolean onKeyUp(int keyCode, KeyEvent event) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_DPAD_LEFT:
                case KeyEvent.KEYCODE_A: keyLeft = false; return true;
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                case KeyEvent.KEYCODE_D: keyRight = false; return true;
                case KeyEvent.KEYCODE_DPAD_DOWN:
                case KeyEvent.KEYCODE_S: keyDown = false; return true;
                case KeyEvent.KEYCODE_SHIFT_LEFT:
                case KeyEvent.KEYCODE_SHIFT_RIGHT: keyRun = false; return true;
                case KeyEvent.KEYCODE_SPACE:
                case KeyEvent.KEYCODE_BUTTON_A:
                    keyJump = false;
                    keyJumpRelease = true;
                    return true;
            }
            return super.onKeyUp(keyCode, event);
        }
    }

    private static final class Block {
        final float x, y, w, h;
        Block(float x, float y, float w, float h) {
            this.x = x; this.y = y; this.w = w; this.h = h;
        }
    }
}

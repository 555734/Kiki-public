# Platform Runner prototype

Original one-player Android platformer prototype built from the movement-system requirements in the supplied reference video.

Included movement:
- Walk/run with acceleration, friction and skidding
- Variable-height jump
- Jump buffering and coyote time
- Chained 1st/2nd/3rd jump with stronger third jump
- Wall slide and wall kick
- Reverse/somersault jump after a high-speed skid
- Crouch jump / backflip-style jump
- Air down input / ground pound

Intentionally omitted:
- Coins / collectibles
- Fireballs / projectiles
- Pipes
- Enemies
- Power-ups
- Franchise characters, logos, sounds and art

Visuals are original procedural Canvas artwork drawn by the app itself.
